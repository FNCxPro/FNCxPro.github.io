const bulb        = document.getElementById('hue-bulb'),
      bulbOutline = document.getElementById('outline'),
      bulbColor   = document.getElementById('color')
      dark        = typeof darkMode === 'number' ? darkMode : true,
      hue         = jsHue(),
      hasUsername = localStorage.getItem('username') ? true : false

let poweredState = false
let ready = false
let bridge 
let user
let lights = []
lightsToControl = (typeof lightsToControl === 'string' ? lightsToControl : 'Light 1,Light 2').split(',')

if (dark) {
  bulbOutline.setAttribute('fill', 'black')
} else {
  bulbOutline.setAttribute('fill', 'white')
}

function log(message, ...args) {
  let newMessage = message + ' ' + args.join(' ')
  document.getElementById('messages').appendChild(document.createTextNode(newMessage))
}
function clearLog() {
  document.getElementById('messages').innerHTML = ''
}
function bulbState(powered = false) {
  poweredState = powered
  if (powered) {
    bulbColor.setAttribute('fill', '#ffcc00')
    bulbColor.setAttribute('fill-opacity', '1')
  } else {
    bulbColor.setAttribute('fill', dark ? '#000000' : '#ffffff')
    bulbColor.setAttribute('fill-opacity', '0.5')
  }
}

bulbState(false)
hue.discover().then((bridges) => {
  if (bridges.length === 0) {
    log('No bridges found!')
  } else {
    bridges.forEach((bridge) => console.log('Bridge found at IP address', bridge.internalipaddress))
    bridge = hue.bridge(bridges[0].internalipaddress)
    if (hasUsername) {
      user = bridge.user(localStorage.getItem('username'))
      ready = true
      onReady()
    } else {
      log('Press link button, then press bulb aboves')
      function clickListener(sender, e) {
        clearLog()
        bridge.createUser('huewidget#homescreen').then((data) => {
          log('Created user...')
          localStorage.setItem('username', data[0].success.username)
          console.log('username', localStorage.getItem('username'))
          bulb.removeEventListener('click', clickListener)
          user = bridge.user(localStorage.getItem('username'))
          ready = true
          onReady()
        })
      }
      bulb.addEventListener('click', clickListener)
    }
    
  }
})

function onReady() {
  clearLog()
  user.getLights().then((_lights) => {
    for (var key in _lights) {
      if (!_lights.hasOwnProperty(key)) continue
      let light = _lights[key]
      light.idx = key
      if (lightsToControl.indexOf(light.name) !== -1) {
        lights.push(light)
      }
    }
  })
  bulb.addEventListener('click', (sender, e) => {
    if (poweredState) {
      bulbState(false)
    } else {
      bulbState(true)
    }    
    lights.forEach((light) => {
      user.setLightState(light.idx, { on: poweredState }).then((...args) => console.log(...args)).catch((err) => {
        log(poweredState.toString() + err.toString())
        console.error(err.toString())
        console.error(err)
        console.error(poweredState)
      })
    })
  })
}
